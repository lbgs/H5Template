<?php

return [
    'Group'        => '所属组别',
    'Loginfailure' => '登录失败次数',
    'Login time'   => '最后登录',
];

Demo: [http://webjeda.com/cards](http://webjeda.com/cards)

## Installation
* Fork the repository
* Go to settings and set Github Pages source as master.
* Your new site should be ready.

For more themes visit - [https://jekyll-themes.com](https://jekyll-themes.com)
<?php

namespace app\model;


class AdminMenu extends Base {
    //
}

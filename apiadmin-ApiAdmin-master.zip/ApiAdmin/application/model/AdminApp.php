<?php

namespace app\model;


class AdminApp extends Base {

}

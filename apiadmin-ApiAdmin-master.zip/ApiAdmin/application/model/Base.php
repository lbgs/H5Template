<?php
/**
 * 模型基类
 * @since   2017/07/25 创建
 * @author  zhaoxiang <zhaoxiang051405@gmail.com>
 */

namespace app\model;


use think\Model;

class Base extends Model {

}